<?php

require 'Views/regis.view.php';


header('Location: /');
exit();