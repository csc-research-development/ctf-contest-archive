<!DOCTYPE html>
<html lang="en" class="h-full bg-gray-100">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DEMO</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="h-full">

<div class="min-h-full">
  <main>
    <h1>Regis Form</h1>
    <form method="post" action="/">
        <label for="uname"></label>
        <input type="text" id="uname" name="uname"><br><br>
        <label for="pw"></label>
        <input type="text" id="pw" name="pw"><br>
        <button type="submit" style="background-color: red">Submit</button>
    </form>
  </main>
</div>

</body>
</html>