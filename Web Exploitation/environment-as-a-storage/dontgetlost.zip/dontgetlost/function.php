<?php


function dd($value){
    echo "<pre>";
    var_dump($_SERVER);
    echo "</pre>";

    die();    
};