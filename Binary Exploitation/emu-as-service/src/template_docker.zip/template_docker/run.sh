#!/bin/bash

cd /home/ctf && ./babyret2win